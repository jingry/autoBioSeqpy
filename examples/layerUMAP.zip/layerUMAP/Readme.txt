layerUMAP: A tool for visualizing and understanding deep learning models in biological sequence classification using UMAP
========================================================================

Author
========================================================================
jingry@scu.edu.cn
ljs@swmu.edu.cn

Overview
========================================================================
As the main plugin of autoBioSeqpy toolbox, layerUMAP allows visual analysis of trained DL models in one-line-command. It provides several parameters and options that can be easily set by the users, including: 
--paraFile: a path parameter containing information about the trained DL models,
--outFigFolder: a path parameter specifying the output folder in which the result file named UMAP.pdf will be saved. 
--n_neighbors: a UMAP parameter controlling how UMAP balances local versus global structure in the data.
--min_dist: a UMAP parameter controlling how tightly UMAP is allowed to pack points together.
--metric: a UMAP parameter controlling how distance is computed in the ambient space of the input data.
--grid_n_neighbors and --grid_min_dist: two parameters performing a grid search for the --n_neighbors and --min_dist parameters, respectively. The values after two parameters will be passed to arange() in numpy (i.e. used as 'start stop stepSize'). Note that if '--grid_min_dist' or '--grid_n_neighbors' is used, '--min_dist' or '--n_neighbors' will be ignored respectively. 
--theme: a parameter setting the color, background and theme for plotting. 
--figWidth and --figHeight: two parameters setting the size of the output figures.
--interactive: a parameter specifying layer name or layer index for plotting.
=========================================================================

Examples
=========================================================================
Case1:  classifying Gram-negative bacterial secreted protein from primary sequence
Case2:  identifying cell types from single-cell gene expression data

Usage
=========================================================================
Case1

The user first uses the following command to train the CNN model:
########################################################################################
python running.py --dataType protein --dataEncodingType onehot  --dataTrainFilePaths examples/layerUMAP/Case1/data/T1SS_train.txt examples/layerUMAP/Case1/data/T2SS_train.txt examples/layerUMAP/Case1/data/T3SS_train.txt examples/layerUMAP/Case1/data/T4SS_train.txt examples/layerUMAP/Case1/data/T5SS_train.txt examples/layerUMAP/Case1/data/T7SS_train.txt --dataTrainLabel 0 1 2 3 4 5 --dataTestFilePaths examples/layerUMAP/Case1/data/T1SS_test.txt examples/layerUMAP/Case1/data/T2SS_test.txt examples/layerUMAP/Case1/data/T3SS_test.txt examples/layerUMAP/Case1/data/T4SS_test.txt examples/layerUMAP/Case1/data/T5SS_test.txt examples/layerUMAP/Case1/data/T7SS_test.txt --dataTestLabel 0 1 2 3 4 5 --modelLoadFile examples/layerUMAP/Case1/model/CNN+GlobalMaxPooling.py --verbose 1 --outSaveFolderPath tmpOut --savePrediction 1 --saveFig 1 --batch_size 40 --epochs 50 --spcLen 2000 --shuffleDataTrain 1 --modelSaveName tmpMod.json --weightSaveName tmpWeight.bin --noGPU 0 --paraSaveName parameters.txt --labelToMat 1 --loss categorical_crossentropy
########################################################################################

If the user wants to train other models, just change the path and file name after the --modelLoadFile, e.g.:

--modelLoadFile examples/layerUMAP/Case1/model/CNN-BiGRU.py
--modelLoadFile examples/layerUMAP/Case1/model/CNN-BiLSTM.py
--modelLoadFile examples/layerUMAP/Case1/model/BiLSTM.py
--modelLoadFile examples/layerUMAP/Case1/model/BiGRU.py

After training the model, users can enter the following command to visualize the model using layerUMAP:
########################################################################################
python tool/layerUMAP.py --paraFile tmpOut/parameters.txt --outFigFolder tmpOut --metric chebyshev --theme fire --n_neighbors 28 --min_dist 0.9
########################################################################################
The UMAP.pdf is save in the tmpOut file together with the model parameters, weights, results and other figures.

Users can visualize any hidden layer interactively using the following commands:
########################################################################################
python tool/layerUMAP.py --paraFile tmpOut/parameters.txt --outFigFolder tmpOut --metric chebyshev --theme fire --n_neighbors 28 --min_dist 0.9 --interactive 1
########################################################################################
=========================================================================
Case2:

Again, the user needs to train the model first(CellBench and Pancreatic) :
=========================================================================
conda activate keras2.4
conda env list
python running.py --dataType other --dataEncodingType other --dataTrainFilePaths examples/layerUMAP/Case2/data/CellBench/A549 examples/layerUMAP/Case2/data/CellBench/H1975 examples/layerUMAP/Case2/data/CellBench/H2228 examples/layerUMAP/Case2/data/CellBench/H838 examples/layerUMAP/Case2/data/CellBench/HCC827 --dataTrainLabel 0 1 2 3 4 --modelLoadFile examples/layerUMAP/Case2/model/RFCN.py --savePrediction 1 --saveFig 1 --batch_size 128 --shuffleDataTrain 1 --showFig 0 --modelSaveName tmpMod.json --weightSaveName tmpWeight.bin --noGPU 0 --paraSaveName parameters.txt --spcLen 9887 --labelToMat 1 --epochs 20 --dataSplitScale 0.9 --outSaveFolderPath tmpOut --loss categorical_crossentropy --optimizer optimizers.Adam(lr=0.0005,clipnorm=0.1)

python running.py --dataType other --dataEncodingType other --dataTrainFilePaths examples/layerUMAP/Case2/data/Pancreatic/alpha examples/layerUMAP/Case2/data/Pancreatic/beta examples/layerUMAP/Case2/data/Pancreatic/delta examples/layerUMAP/Case2/data/Pancreatic/gamma --dataTrainLabel 0 1 2 3 --modelLoadFile examples//layerUMAP/Case2/model/RFCN1.py --savePrediction 1 --saveFig 1 --batch_size 128 --shuffleDataTrain 1 --showFig 0 --modelSaveName tmpMod.json --weightSaveName tmpWeight.bin --noGPU 0 --paraSaveName parameters.txt --spcLen 15642 --labelToMat 1 --epochs 20 --dataSplitScale 0.9 --outSaveFolderPath tmpOut --loss categorical_crossentropy --optimizer optimizers.Adam(lr=0.0005,clipnorm=0.1)
=========================================================================

Use the following command to visualize the last hidden layer:
=========================================================================
python tool/layerUMAP.py --paraFile tmpOut/parameters.txt --outFigFolder tmpOut --metric cosine --n_neighbors 28 --min_dist 0.8

python tool/layerUMAP.py --paraFile tmpOut/parameters.txt --outFigFolder tmpOut --metric chebyshev --interactive 1 --grid_n_neighbors 2 30 2 --grid_min_dist 0.1 1 0.1


=========================================================================
install

conda install -c conda-forge umap-learn
pip install umap-learn
pip install umap-learn[plot]















