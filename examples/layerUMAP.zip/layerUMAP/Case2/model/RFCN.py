# -*- coding: utf-8 -*-
"""
Created on Fri Nov 12 21:00:32 2021

@author: jingr
"""

from keras.models import Sequential, Model
from keras.layers import Dense, Dropout, Activation
from keras.utils import np_utils
from keras import optimizers
from keras.layers import Input, LayerNormalization

LN = LayerNormalization(axis=-1)
HL1 = Dense(256,activation = 'relu')
HL2 = Dense(256*4,activation = 'relu')
HL3 = Dense(256,activation = 'relu')

x_in = Input(shape=(9887 ,))
x = Dense(5120,activation = 'relu')(x_in)
x = Dropout(0.15)(x)
x = Dense(256,activation = 'relu')(x)
x = Dropout(0.15)(x)

for i in range(10):
    x1 = LN(x)
    x1 = HL1(x1)
    x1 = Dropout(0.15)(x1)
    x1 = HL2(x1)
    x1 = Dropout(0.15)(x1)
    x += HL3(x1)
x = Dense(128)(x)
x = Dropout(0.15)(x)
x = Dense(5)(x)
x = Activation('softmax')(x)
model = Model(inputs=[x_in],outputs=x)
